stripe.onclick = function() {
  stripe.classList.add('animate');
};